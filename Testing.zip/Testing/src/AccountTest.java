import static org.junit.Assert.assertEquals;

 

import org.junit.Test;

 

public class AccountTest {
    
    int accountId=369;
    String accountType="saving";
    int balance=9000;
    Account acc=new Account(accountId,accountType,balance);
    
    @Test
    public void test1() {
        Account expected=new Account(369,"saving",9000);
        
        assertEquals(expected.deposit(9000),true);
    }
    
    @Test
    public void test2() {
        Account expected=new Account(369,"saving",9000);
        
        assertEquals(expected.deposit(0),false);

 

    }
}
