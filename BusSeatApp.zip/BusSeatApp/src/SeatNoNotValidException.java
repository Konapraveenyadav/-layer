//make the necessary change to make this class a Exception 
public class SeatNoNotValidException extends Exception{
	
	SeatNoNotValidException(String string) {
		super(string);
	}
}
