import java.util.Scanner;

public class UserInterface {
	public static void main(String a[]) {
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter name:");
		String name=scanner.next();
		System.out.println("Enter gender:");
		char gender=scanner.next().charAt(0);
		System.out.println("Enter age:");
		int age=scanner.nextInt();
		System.out.println("Enter seat Number:");
		int seatNo=scanner.nextInt();
		Customer cObj=new Customer();
		cObj.setCustomerName(name);
		cObj.setGender(gender);
		cObj.setAge(age);
		
		try{
		    cObj.setSeatNo(seatNo);
		    System.out.println("Seat number allocated");
		}
		
		catch(SeatNoNotValidException i){
		    System.out.println(i.getMessage());
		}
		
        finally{
            scanner.close();
        }
		
		//fill the code
	}
}
