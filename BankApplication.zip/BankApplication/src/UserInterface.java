import java.util.Scanner;

public class UserInterface {

	public static void main(String a[]) {
		Scanner scanner = new Scanner(System.in);
		int noOfEmployees = scanner.nextInt();
		String employees[] = new String[noOfEmployees];
		for (int i = 0; i < noOfEmployees; i++) {
			employees[i] = scanner.next();
		}
		
		int count = 0;
		StringBuffer buffer = new StringBuffer();
		
		for (String s : employees) {
			String[] info = new String[2];
			info = s.split(",");
			info[1] = info[1].replaceAll(":", "");
			int number = Integer.parseInt(info[1]);
			if (number > 930) {
				count++;
				buffer.append(info[0] + " ");
			}
		}
		
		
		System.out.println(count + " " + buffer.toString() + "are late");
        scanner.close();
	}

}