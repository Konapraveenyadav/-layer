package com.cg.eis.pl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.eis.bean.Department;
import com.cg.eis.bean.Employee;

public class EmployeeRepository {
	
	public static List<Department> getDepartments()
	{
		List<Department>dlist=new ArrayList<>();
		dlist.add(new Department(10,"IT",100));
		dlist.add(new Department(20,"Sales",101));
		dlist.add(new Department(30,"Marketing",102));
		dlist.add(new Department(40,"HR",103));
		return dlist;
		
	}
	public static List<Employee> getEmployees()
	{
		List<Employee>elist=new ArrayList<>();
		elist.add(new Employee(100,"Anitha","Bhairi","anitha@cg.com","7013829676",LocalDate.of(2012, 6, 14),"President",50000.00,null,new Department(10,"IT",100)));
		elist.add(new Employee(101,"Raji","Bhairi","raji@cg.com","7702154117",LocalDate.of(2015, 8, 3),"Sales_Mgr",47000.00,100,new Department(20,"Sales",101)));
		elist.add(new Employee(102,"Rajesh","Gollangi","rajesh@cg.com","9963747884",LocalDate.of(2011, 3, 22),"Marketing",16000.00,100,new Department(30,"Marketing",102)));
		elist.add(new Employee(103,"Yogita","jadhav","yjadhav@cg.com","9666362303",LocalDate.of(2015, 8, 3),"Sales_Mgr",47000.00,100,null));
		elist.add(new Employee(104,"Virat","Kohli","virat@cg.com","9949484110",LocalDate.of(2015, 8, 3),"Sales_Mgr",47000.00,100,null));
		elist.add(new Employee(105,"Yamuna","Smiley","smiley@cg.com","9493434936",LocalDate.of(2015, 8, 3),"Sales_mgr",45000.00,null,new Department(20,"Sales",101)));
		elist.add(new Employee(106,"Pavani","Potru","pavani@cg.com","7337059351",LocalDate.of(2015, 8, 3),"sales_mgr",45000.00,100,new Department(20,"Sales",101)));
		return elist;
	}

}
