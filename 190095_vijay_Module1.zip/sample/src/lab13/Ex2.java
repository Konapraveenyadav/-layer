package lab13;

import java.util.Scanner;
interface Space
{
	String space(String s);
}
class Ex2 {
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a string");
	String a=sc.next();
	Space sp=(b)->giveSpace(b);
	System.out.println(sp.space(a));
	sc.close();
	
}
static String giveSpace(String s1)
{ 
	String c="";
	for(int i=0;i<s1.length();i++)
			{
		c=c+s1.charAt(i)+" ";
			}
	return c;
}
}
