package lab13;
import java.util.Scanner;
interface UsernamePassword
{
	boolean UsernamePassword(String user, String pws);
}
public class Ex3 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter username");
		String userName=sc.next();
		System.out.println("enter password");
		String pws=sc.next();
		UsernamePassword ups=(a,b)->Authentication(a,b);
		if(ups.UsernamePassword(userName, pws))
		{
			System.out.println("Logged in successfully");
			
		}
		else
		{
			System.out.println("loginn failure");
		}
		sc.close();
	}
	static boolean Authentication(String x, String y)
	{
		
		String userName="smiley";
		String password="virat";
		if(x.equals(userName)&&y.equals(password))
		{
			return true;
		}
		return false;
	}
   
}
