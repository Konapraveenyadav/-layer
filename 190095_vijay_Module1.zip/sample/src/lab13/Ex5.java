package lab13;
import java.util.function.Function;

public class Ex5 {
	public static void  main(String[] arg)
	{
	
		Ex5 p=new Ex5();
		Function<Integer,Integer> h=p::fact1;
			int y=h.apply(5);
			System.out.println(y);
		
	}
			public int fact1(int x)
			{

	int factres=1;	

		
				for(int i=1;i<=x;i++)
				{
					factres=factres*i;
				}
				 return  factres;
}
}
