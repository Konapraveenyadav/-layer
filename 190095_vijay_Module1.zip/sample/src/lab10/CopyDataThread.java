package lab10;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;


class CopyDataThread extends Thread
	{
		FileInputStream fisObj;
		FileOutputStream fosObj;
		public CopyDataThread(FileInputStream fisObj, FileOutputStream fosObj)
		{
			this.fisObj=fisObj;
			this.fosObj=fosObj;
		}
		public void run()
		{
			try {
				int n,i=0;
				while((n=fisObj.read())!=-1)
				{
					fosObj.write(n);
					i++;
					if(i%10==0) {
						System.out.println("10 characters are copied");
						try {
							sleep(10000);
						}catch(InterruptedException e)
						   {
							System.out.println("Exception error");
						   }
						}
					}
			fisObj.close();
			fosObj.close();
			System.out.println("Copied Successfully");
			}catch (IOException e) {
				System.out.println(e);
			}
		}
}