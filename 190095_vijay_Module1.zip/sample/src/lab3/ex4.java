package lab3;
import java.util.Scanner;
public class ex4 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		String str=sc.next();
		CountChar(str);
		sc.close();
	}

 static void CountChar(String str)
{
	int count[]=new int[200];
	int i=0,f=0;
	for(i=0;i<str.length();i++)
		count[str.charAt(i)]++;
	char ch[]=new char[str.length()];
		for(i=0;i<str.length();i++)
		{
			ch[i]=str.charAt(i);
			f=0;
			for(int j=0;j<=i;j++)
			{
				if(str.charAt(i)==ch[j])
					f++;
			}
			if(f==1)
				System.out.println("No occurance of charaters in string: "+str.charAt(i)+ " is: "+count[str.charAt(i)]);
	
		}
		
	}
     

}