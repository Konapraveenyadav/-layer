package lab3;
import java.util.Arrays;

public class Ex3 {
       int[] getSorted(int a[])
       {
    	   int len=a.length;
    	   int b[]=new int[len];
    	   int j=0;
    	   int temp;
    	   for(int c=a.length-1;c>=0;c--)
       
    	   {
    		   b[j]=a[c];
    		   j++;
    	   }
    	   for(int p=0;p<len;p++)
    	   {
    		   for(int q=p+1;q<len;q++)
    		   {
    			   if(b[p]>b[q])
    			   {
    				   temp=b[p];
    				   b[p]=b[q];
    				   b[q]=temp;
    			   }
    		   }
    	   }
    	   return b;
       }
       public static void main(String args[])
       {
    	   int a[]=new int[5];
    	   int c[]=new int[5];
    	   a[0]=5;
    	   a[1]=3;
    	   a[2]=7;
    	   a[3]=1;
    	   a[4]=4;
    	   Ex3 e=new Ex3();
    	   c=e.getSorted(a);
    	   System.out.println(Arrays.toString(c));
       }
}
