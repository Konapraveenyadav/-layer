package lab3;
import java.util.Arrays;
import java.util.Scanner;
class Alphabet {
	int i=0;
	public void alpha(String[] arr)
	{
		int len=arr.length;
        Arrays.sort(arr);
        System.out.println(Arrays.toString(arr));
        if(len%2 !=0)
        {
        	for(int i=0;i<(len/2)+1;i++) {
        		arr[i]=arr[i].toUpperCase();
        	}
        	for(int i=(len/2)+1;i<len;i++)
        	{
        		arr[i]=arr[i].toLowerCase();
        	}
        }
        else {
        	   for(int i=0;i<(len/2);i++)
        			{
                         arr[i]=arr[i].toUpperCase();
        			}
        	   for(int i=(len/2);i<len;i++) {
        		   arr[i]=arr[i].toLowerCase();	
        	}
        }
        System.out.println(Arrays.toString(arr));
        
	}
}
public class Ex2 {
     public static void main(String[] args)
     {
    	 Scanner sc=new Scanner(System.in);
    			 Alphabet alphabetObj=new Alphabet();
    			 System.out.println("Enter the number of elements: ");
                  int elements=sc.nextInt();
                  String arr[]=new String[elements];
                  System.out.println("Enter the elements: ");
                  for(int i=0;i<elements;i++)
                	  arr[i]=sc.next().toLowerCase();
                  
                  alphabetObj.alpha(arr);
                  sc.close();
     }
}
