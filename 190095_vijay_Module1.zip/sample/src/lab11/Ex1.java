package lab11;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
class MusicPlayTask implements Runnable{
	@Override
	public void run()
	{
		System.out.println("Music play is executing");
		try {
			Thread.sleep(2000);
		} catch(InterruptedException e)
		{
			System.out.println("Music play Exception");
		}
		System.out.println("Music play resumed after sleep");
	}
}
class CopyTask implements Runnable
{
	@Override
	public void run()
	{
		System.out.println("Copy Task is executing");
		try {
			Thread.sleep(2000);
		}catch(InterruptedException e)
		{
			System.out.println("Copy Task Exception");
		}
		System.out.println("Copy Task is resumed after sleep");
	}
}
public class Ex1 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Thread Executor & Executor Service Demo \n 1.Executor \n 2.Executor Service \n Enter your choice");
		int ch=sc.nextInt();
		if(ch==1) {
			ExecutorService exs1=Executors.newSingleThreadExecutor();
			ExecutorService exs2=Executors.newFixedThreadPool(10);
			exs1.execute(new MusicPlayTask());
			exs2.execute(new CopyTask());
			exs1.shutdown();
			exs2.shutdown();
		}
		else {
			System.out.println("Enter valid choice");
		}
		sc.close();
	}

}
