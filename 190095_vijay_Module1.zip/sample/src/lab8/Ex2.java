
package lab8;
import java.util.Scanner;
import java.io.*;
public class Ex2 {
	public static void main(String[] args)
	{
		String st;
		Scanner sc=new Scanner(System.in);
		st=sc.nextLine();
		String li=null;
		int count=1;
		try {
			
		    
		    FileReader fileReader=new FileReader(st);
		    BufferedReader bufferedReader=new BufferedReader(fileReader);
		    while((li=bufferedReader.readLine())!=null)
		    {

		    	System.out.println("Line No "+count+" is "+ li);
		    	count++;
	       
		    }
		    bufferedReader.close();
		}
		
		catch(IOException e)
		{
			System.out.println("Exception error");
		sc.close();
	}
}
}