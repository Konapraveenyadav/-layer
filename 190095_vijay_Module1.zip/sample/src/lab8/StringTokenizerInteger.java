package lab8;
import java.util.*;
public class StringTokenizerInteger {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		StringTokenizer st= new StringTokenizer(s);
		int n=0,sum=0;
		while(st.hasMoreElements())
		{
			String t=(String) st.nextElement();
			n=Integer.parseInt(t);
			sum=n+sum;
			System.out.print(n+" ");
		}
		System.out.println();
		System.out.println("sum : "+sum);
	  sc.close();
	}
}

