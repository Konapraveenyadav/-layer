package lab8;
import java.util.Scanner;
public class Ex5 {
	public void counting(String str)
	{
		
		int n=0;
		char ch[]=str.toCharArray();
		int len=ch.length;
		for(int i=0;i<len-1;i++)
		{
			char c=ch[i];
			char b=ch[i+1];
			if(c>=b)
			{
				n=1;
				break;
			}
		}
		if(n==0)
		{
			System.out.println("Positive string");
		}
		else
			System.out.println("Not a positive string");
		
	}
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a string");
		String str=sc.nextLine().toUpperCase();
		Ex5 ob=new Ex5();
		ob.counting(str);
		sc.close();
		
	}

}
